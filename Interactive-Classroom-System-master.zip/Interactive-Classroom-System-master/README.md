# Interactive-Classroom-System
The Interactive Classroom  application is a collaborative teaching tool to assist the students to learn in an interactive manner.The system can be used to increase  student faculty interaction and also increase their involvement with the college.
